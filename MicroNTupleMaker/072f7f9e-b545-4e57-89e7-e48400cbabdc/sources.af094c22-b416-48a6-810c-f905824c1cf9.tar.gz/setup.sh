# Setup ATLAS
setupATLAS -2
lsetup "root 6.20.06-x86_64-centos7-gcc8-opt"
