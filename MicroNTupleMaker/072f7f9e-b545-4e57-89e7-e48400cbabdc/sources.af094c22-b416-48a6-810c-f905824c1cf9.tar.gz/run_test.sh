#./exe/MicroNTupleMaker user.ebusch.508550.MGPy8EG_SVJSChan_750_3.v3a.mc16a_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v3/
#./exe/MicroNTupleMaker user.ebusch.364702.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v4/
#./exe/MicroNTupleMaker user.ebusch.515507.MGPy8EG_SVJSChan2j_3000_2.v6c.mc20a_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v6/
./exe/MicroNTupleMaker user.rgarg.515500.MGPy8EG_SVJSChan2j_2000_4.v7a.mc20e_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v7/
#./exe/MicroNTupleMaker user.ebusch.515507.MGPy8EG_SVJSChan2j_3000_2.v6c.mc20d_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v6/
#./exe/MicroNTupleMaker user.ebusch.515507.MGPy8EG_SVJSChan2j_3000_2.v6b.mc20e_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v6/
#./exe/MicroNTupleMaker user.rgarg.364704.Pythia8EvtGen_A14NNPDF23LO_jetjet_JZ4WithSW.v7a.mc20e_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v7/
#./exe/MicroNTupleMaker user.ebusch.364706.Pythia8EvtGen_A14NNPDF23LO_jetjet_JZ6WithSW.v6b.mc20d_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v6/
#./exe/MicroNTupleMaker user.ebusch.364706.Pythia8EvtGen_A14NNPDF23LO_jetjet_JZ6WithSW.v6b.mc20e_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v6/
#./exe/MicroNTupleMaker user.ebusch.364703.Pythia8EvtGen_A14NNPDF23LO_jetjet_JZ3WithSW.v5a.mc20e_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v5/
#./exe/MicroNTupleMaker user.ebusch.364707.Pythia8EvtGen_A14NNPDF23LO_jetjet_JZ7WithSW.v3a.mc16d_tree.root true /eos/atlas/atlascerngroupdisk/phys-exotics/jdm/svjets-schannel/v3/

